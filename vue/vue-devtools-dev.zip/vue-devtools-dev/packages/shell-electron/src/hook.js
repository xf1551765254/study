import { installHook } from '@back/hook'
import { target } from '@utils/env'

installHook(target)
